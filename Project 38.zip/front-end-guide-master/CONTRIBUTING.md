## How To Contribute

Thank you in advance for your contributions! This repository doesn't really contain code, it serves to share our technologies with the world, hence we are not really expecting a lot of contributions from the community.

If you would like to fix a typo or propose suggestions, you are welcome to. Simply make sure your changes are being proofread and then submit a Pull Request. Thanks! :smile:
